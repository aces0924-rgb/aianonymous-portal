import Link from 'next/link';

export default function TrackCard({ track }: { track: any }) {
  return (
    <div className="bg-gray-900 border border-cyan-800 rounded-xl p-5 hover:border-cyan-400 transition-colors shadow-[0_0_15px_rgba(0,240,255,0.1)] relative overflow-hidden group">
      <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500 group-hover:shadow-[0_0_10px_#00f0ff] transition-all"></div>
      <div className="flex flex-col gap-3">
        <h3 className="text-2xl font-bold text-white truncate group-hover:text-cyan-300 transition-colors">{track.title}</h3>
        
        {track.songUrl && (
          <a href={track.songUrl} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 text-sm truncate flex items-center gap-1">
            ▶ 楽曲を聴く / 視聴する
          </a>
        )}
        
        <div className="mt-2 flex gap-3">
          <Link href={`/tracks/${track.id}`} className="px-5 py-2 bg-purple-900/50 border border-purple-500 text-purple-300 rounded-full text-xs font-bold hover:bg-purple-600 hover:text-white transition-all shadow-[0_0_10px_rgba(188,19,254,0.2)]">
            歌詞 ＆ AI考察を読む
          </Link>
        </div>
      </div>
    </div>
  );
}
