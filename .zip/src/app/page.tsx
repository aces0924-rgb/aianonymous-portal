export const dynamic = 'force-dynamic'

import prisma from '@/lib/prisma'
import TrackCard from '@/components/TrackCard'

export default async function Home() {
  const news = await prisma.news.findMany({ orderBy: { createdAt: 'desc' } })
  const schedule = await prisma.schedule.findMany({ orderBy: { order: 'asc' } })
  const rules = await prisma.rule.findMany({ orderBy: { order: 'asc' } })
  const tracks = await prisma.track.findMany({ orderBy: { id: 'desc' } })

  return (
    <main className="min-h-screen bg-black text-white selection:bg-cyan-500 selection:text-white font-sans">
      
      {/* Hero Section */}
      <section className="relative flex items-center justify-center h-screen bg-gradient-to-b from-gray-900 to-black overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, #00f0ff 0%, transparent 50%)' }}></div>
        <div className="z-10 text-center space-y-4 px-4">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-600">
            AI-anonymous MUSIC FES.
          </h1>
          <p className="text-xl md:text-2xl text-cyan-100 font-light tracking-wide">生成AI音楽の新しい祭典</p>
          <div className="pt-8">
            <a href="#nav-index" className="px-8 py-3 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition-all shadow-[0_0_15px_rgba(0,240,255,0.5)]">
              詳細を見る
            </a>
          </div>
        </div>
      </section>

      {/* Navigation Index */}
      <nav id="nav-index" className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-4xl mx-auto px-6 py-3 flex flex-wrap items-center justify-center gap-2 md:gap-4">
          {[
            { href: '#news', label: 'お知らせ', icon: '📢' },
            { href: '#schedule', label: 'スケジュール', icon: '📅' },
            { href: '#guidelines', label: '募集内容', icon: '📋' },
            { href: '#tracks', label: '参加作品', icon: '🎵' },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="px-4 py-2 rounded-full text-sm font-bold text-gray-300 hover:text-white hover:bg-cyan-900/50 border border-transparent hover:border-cyan-700 transition-all flex items-center gap-2"
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </a>
          ))}
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-20 space-y-32">
        
        {/* News Section */}
        <section id="news" className="space-y-8 scroll-mt-20">
          <h2 className="text-3xl font-bold border-l-4 border-cyan-500 pl-4">お知らせ</h2>
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-lg">
            {news.length === 0 ? (
              <p className="text-gray-400">現在お知らせはありません。</p>
            ) : (
              <ul className="space-y-4">
                {news.map((n: any) => (
                  <li key={n.id} className="border-b border-gray-800 pb-4 last:border-0 last:pb-0">
                    <span className="text-sm text-cyan-400 font-mono block mb-1">
                      {`${n.createdAt.getFullYear()}/${n.createdAt.getMonth() + 1}/${n.createdAt.getDate()}`}
                    </span>
                    <h3 className="text-lg font-bold text-white">{n.title}</h3>
                    {n.content && <p className="text-gray-300 mt-2">{n.content}</p>}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* Schedule Section */}
        <section id="schedule" className="space-y-12 scroll-mt-20">
          <h2 className="text-3xl font-bold border-l-4 border-cyan-500 pl-4 mb-12">スケジュール</h2>
          
          <div className="relative">
            {/* Central Line (Desktop) */}
            <div className="absolute left-4 md:left-1/2 md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400 via-purple-500 to-blue-500 shadow-[0_0_15px_rgba(0,240,255,0.5)]"></div>

            <div className="space-y-12 md:space-y-0">
              {schedule.length === 0 ? (
                <p className="text-gray-400 pl-12 md:text-center md:pl-0">スケジュールは後日発表されます。</p>
              ) : (
                schedule.map((s: any, idx: number) => {
                  const isEven = idx % 2 === 0;
                  const neonColorClasses = isEven ? 'text-purple-500 drop-shadow-[0_0_8px_rgba(188,19,254,0.6)]' : 'text-cyan-400 drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]';
                  const ringColorClasses = isEven ? 'border-purple-500 shadow-[0_0_10px_#bc13fe]' : 'border-cyan-400 shadow-[0_0_10px_#00f0ff]';

                  return (
                    <div key={s.id} className={`relative flex items-center justify-between w-full md:mb-16 ${isEven ? 'md:flex-row-reverse' : ''}`}>
                      {/* Spacer for Desktop */}
                      <div className="hidden md:block w-5/12"></div>

                      {/* Timeline Dot (Ring) */}
                      <div className="absolute left-4 md:left-1/2 md:-translate-x-1/2 z-20 flex items-center justify-center">
                        <div className={`w-3.5 h-3.5 border-2 rounded-full bg-black ${ringColorClasses}`}></div>
                      </div>

                      {/* Content Card */}
                      <div className="w-full pl-12 md:pl-0 md:w-5/12 group">
                        <div className={`mb-1 font-black text-lg md:text-xl font-mono tracking-tighter ${neonColorClasses} ${isEven ? 'md:text-left' : 'md:text-right'}`}>
                          {s.date}
                        </div>
                        <div className={`bg-gray-900/60 backdrop-blur-md border border-gray-800 p-5 rounded-2xl shadow-2xl transition-all group-hover:border-gray-600 group-hover:bg-gray-900/80 ${isEven ? 'md:text-left' : 'md:text-right'}`}>
                          <p className="text-white font-bold leading-snug">{s.title}</p>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>

        {/* Guidelines Section (旧: 参加ルール) */}
        <section id="guidelines" className="space-y-8 scroll-mt-20">
          <h2 className="text-3xl font-bold border-l-4 border-purple-500 pl-4">募集内容</h2>
          
          {/* Catchphrase */}
          <div className="text-center py-8 space-y-4">
            <p className="text-2xl md:text-3xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
              「あなたの「好き」に、言い訳はいらない。」
            </p>
            <div className="max-w-2xl mx-auto space-y-2 text-gray-400 text-sm md:text-base leading-relaxed">
              <p>AIが生んだメロディか、人が紡いだ言葉か。</p>
              <p>そんな境界線を超えて、ただ「良い」と思った直感を信じたい。</p>
              <p className="text-cyan-300 font-medium pt-2">
                AI-Anonymous FES. は、制作者の情報を伏せ、<br className="hidden md:block" />
                純粋に楽曲の魅力だけで繋がる匿名音楽フェスです。
              </p>
            </div>
          </div>
          
          {/* Rule Sections */}
          <div className="space-y-6">
            {rules.length === 0 ? (
              <p className="text-gray-400">募集内容は準備中です。</p>
            ) : (
              rules.map((r: any) => {
                const lines = r.content.split('\n');
                const heading = lines[0];
                const body = lines.slice(1).join('\n');
                return (
                  <div key={r.id} className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 md:p-8 border border-gray-700 hover:border-purple-800 transition-colors">
                    <h3 className="text-lg md:text-xl font-bold text-purple-300 mb-4">{heading}</h3>
                    <div className="text-gray-200 leading-relaxed whitespace-pre-wrap text-sm md:text-base">
                      {body.split('**').map((part: string, i: number) => 
                        i % 2 === 1 
                          ? <strong key={i} className="text-white font-bold">{part}</strong> 
                          : <span key={i}>{part}</span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* Tracks Section */}
        <section id="tracks" className="space-y-8 scroll-mt-20">
          <h2 className="text-3xl font-bold border-l-4 border-cyan-500 pl-4">参加作品</h2>
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-lg">
            {tracks.length === 0 ? (
              <p className="text-gray-400">現在公開されている作品はありません。</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tracks.map((t: any) => (
                  <TrackCard key={t.id} track={t} />
                ))}
              </div>
            )}
          </div>
        </section>

      </div>

      <footer className="border-t border-gray-900 bg-black py-12 mt-20 text-center text-gray-500">
        <p className="mb-4">
          <a href="/admin" className="text-cyan-800 hover:text-cyan-500 transition-colors text-sm">◆ 管理画面ログイン</a>
        </p>
        <p>© 2026 AI-anonymous MUSIC FES.</p>
      </footer>

    </main>
  )
}
