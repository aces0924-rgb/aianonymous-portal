export const dynamic = 'force-dynamic'

import prisma from '@/lib/prisma'
import { addNews, deleteNews, addSchedule, deleteSchedule, addRule, deleteRule, syncTracksFromSheet } from './actions'

export const metadata = {
  title: 'Admin Dashboard',
}

export default async function AdminPage() {
  const news = await prisma.news.findMany({ orderBy: { createdAt: 'desc' } })
  const schedule = await prisma.schedule.findMany({ orderBy: { order: 'asc' } })
  const rules = await prisma.rule.findMany({ orderBy: { order: 'asc' } })
  const tracks = await prisma.track.findMany({ orderBy: { id: 'desc' } })

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold">イベント管理ダッシュボード</h1>
        
        {/* News Section */}
        <div className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-xl font-bold mb-4">お知らせ (News)</h2>
          <form action={addNews} className="flex flex-col gap-2 mb-4">
            <input name="title" placeholder="タイトル" className="border p-2 rounded text-black" required />
            <textarea name="content" placeholder="内容（任意）" className="border p-2 rounded text-black"></textarea>
            <button type="submit" className="bg-blue-600 text-white p-2 rounded hover:bg-blue-700">登録する</button>
          </form>
          <ul className="space-y-2">
            {news.map(n => (
              <li key={n.id} className="flex justify-between items-center border-b pb-2 text-black">
                <div>
                  <span className="font-bold">{n.title}</span> - {n.content}
                </div>
                <form action={deleteNews.bind(null, n.id)}>
                  <button className="text-red-500 text-sm">削除</button>
                </form>
              </li>
            ))}
          </ul>
        </div>

        {/* Schedule Section */}
        <div className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-xl font-bold mb-4">スケジュール (Schedule)</h2>
          <form action={addSchedule} className="flex flex-col gap-2 mb-4">
            <input name="title" placeholder="イベント名 (例: エントリー開始)" className="border p-2 rounded text-black" required />
            <input name="date" placeholder="日時 (例: 2026年4月5日 19:00)" className="border p-2 rounded text-black" required />
            <input name="order" type="number" placeholder="並び順 (数字が小さいほど上)" className="border p-2 rounded text-black" defaultValue={0} />
            <button type="submit" className="bg-green-600 text-white p-2 rounded hover:bg-green-700">登録する</button>
          </form>
          <ul className="space-y-2">
            {schedule.map(s => (
              <li key={s.id} className="flex justify-between items-center border-b pb-2 text-black">
                <div>
                  <span className="font-bold text-gray-500">[{s.order}]</span> {s.title} : {s.date}
                </div>
                <form action={deleteSchedule.bind(null, s.id)}>
                  <button className="text-red-500 text-sm">削除</button>
                </form>
              </li>
            ))}
          </ul>
        </div>

        {/* Rules Section */}
        <div className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-xl font-bold mb-4">募集内容 (Guidelines)</h2>
          <form action={addRule} className="flex flex-col gap-2 mb-4">
            <input name="content" placeholder="募集内容セクション" className="border p-2 rounded text-black" required />
            <input name="order" type="number" placeholder="並び順" className="border p-2 rounded text-black" defaultValue={0} />
            <button type="submit" className="bg-purple-600 text-white p-2 rounded hover:bg-purple-700">登録する</button>
          </form>
          <ul className="space-y-2">
            {rules.map(r => (
              <li key={r.id} className="flex justify-between items-center border-b pb-2 text-black">
                <div>
                  <span className="font-bold text-gray-500">[{r.order}]</span> {r.content}
                </div>
                <form action={deleteRule.bind(null, r.id)}>
                  <button className="text-red-500 text-sm">削除</button>
                </form>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Tracks Sync Section */}
        <div className="bg-white p-6 rounded-xl shadow border-t-4 border-cyan-500">
          <h2 className="text-xl font-bold mb-4 text-cyan-800">参加楽曲データの同期 (Tracks)</h2>
          <form action={syncTracksFromSheet} className="mb-4">
            <button type="submit" className="bg-cyan-600 text-white p-3 rounded-lg hover:bg-cyan-500 w-full font-bold shadow-lg transition-transform active:scale-95">
              🔄 スプレッドシートから最新データを取得・同期する
            </button>
            <p className="text-xs text-gray-500 mt-2 text-center">
              ※ボタンを押すとGoogleスプレッドシートの内容と同期します（AI考察データは保持されます）。
            </p>
          </form>
          <div className="text-sm font-bold text-gray-700 mb-2 border-b pb-2">
            現在登録されている楽曲数: <span className="text-cyan-600 text-lg">{tracks.length}</span> 曲
          </div>
          <ul className="space-y-2 max-h-60 overflow-y-auto">
            {tracks.length === 0 && <li className="text-gray-400 text-sm">データがありません。同期を実行してください。</li>}
            {tracks.map((t: any) => (
              <li key={t.id} className="border-b pb-2 text-black text-sm">
                <div className="font-bold text-base">{t.title}</div>
                <div className="text-gray-500 text-xs truncate">URL: {t.songUrl}</div>
                <div className="text-gray-400 text-xs truncate">投稿者: {t.artistName || "匿名"}</div>
              </li>
            ))}
          </ul>
        </div>

        <div className="text-center mt-8">
          <a href="/" className="text-blue-600 underline">表のページ（公開サイト）を見る</a>
        </div>
      </div>
    </div>
  )
}
