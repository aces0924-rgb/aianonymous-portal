'use server'

import prisma from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import Papa from 'papaparse'

export async function addNews(formData: FormData) {
  const title = formData.get('title') as string
  const content = formData.get('content') as string
  if (!title) return
  await prisma.news.create({ data: { title, content } })
  revalidatePath('/admin')
  revalidatePath('/')
}

export async function deleteNews(id: number) {
  await prisma.news.delete({ where: { id } })
  revalidatePath('/admin')
  revalidatePath('/')
}

export async function addSchedule(formData: FormData) {
  const title = formData.get('title') as string
  const date = formData.get('date') as string
  const order = parseInt(formData.get('order') as string) || 0
  if (!title || !date) return
  await prisma.schedule.create({ data: { title, date, order } })
  revalidatePath('/admin')
  revalidatePath('/')
}

export async function deleteSchedule(id: number) {
  await prisma.schedule.delete({ where: { id } })
  revalidatePath('/admin')
  revalidatePath('/')
}

export async function addRule(formData: FormData) {
  const content = formData.get('content') as string
  const order = parseInt(formData.get('order') as string) || 0
  if (!content) return
  await prisma.rule.create({ data: { content, order } })
  revalidatePath('/admin')
  revalidatePath('/')
}

export async function deleteRule(id: number) {
  await prisma.rule.delete({ where: { id } })
  revalidatePath('/admin')
  revalidatePath('/')
}

const SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1q3rESt0GZG_rs8hk0hU1beeURRttxQKQ1mGFBJNrlyg/export?format=csv&gid=1297990899";

export async function syncTracksFromSheet(formData?: FormData) {
  try {
    const res = await fetch(SHEET_CSV_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error("Failed to fetch sheet data");
    const csvContent = await res.text();

    const parsed = Papa.parse(csvContent, { header: false, skipEmptyLines: true });
    if (parsed.errors.length > 0) {
      console.error("PapaParse errors:", parsed.errors);
    }
    
    // 最初の行（ヘッダー）を除外
    const rows = parsed.data.slice(1) as string[][];

    // Upsertにより、すでに存在するデータの「AI分析結果」などを保護する
    await Promise.all(
      rows.map(async (row) => {
        const timestamp = row[0];
        if (!timestamp) return; // タイムスタンプがない空行はスキップ

        const xAccount = row[1] || "";
        const title = row[2] || "Untitled";
        const songUrl = row[3] || "";
        const audioUrl = row[4] || "";
        const lyrics = row[5] || "";
        const publishConsent = row[6] || "";
        const artistName = row[7] || "";
        const email = row[8] || "";
        const agreedToTerms = row[9] || "";

        await prisma.track.upsert({
          where: { timestamp },
          update: {
            xAccount, title, songUrl, audioUrl, lyrics, publishConsent, artistName, email, agreedToTerms
            // 注意: analysis は更新しないことで、AIが手動で入れた考察文を保持する！
          },
          create: {
            timestamp, xAccount, title, songUrl, audioUrl, lyrics, publishConsent, artistName, email, agreedToTerms
          }
        });
      })
    );

    revalidatePath('/');
    revalidatePath('/admin');
    return { success: true, count: rows.length };
  } catch (err: any) {
    console.error(err);
    return { success: false, error: err.message };
  }
}
